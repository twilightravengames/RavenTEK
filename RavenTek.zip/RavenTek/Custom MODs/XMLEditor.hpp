//
//  XMLEditor.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/21/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef XMLEditor_hpp
#define XMLEditor_hpp

#include <stdio.h>

//represents the XML maps graphically and allows you to edit
//the XML maps graphically
 //For example, we want the player to step on a stone and a door opens.
//door open and stone trigger are messages that are already built in
//Now you can put a stone anywhere you want and a door wherever you want
//and you can duplicate the behavior




#endif /* XMLEditor_hpp */
