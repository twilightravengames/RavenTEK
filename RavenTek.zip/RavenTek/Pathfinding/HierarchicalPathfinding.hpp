//
//  HierarchicalPathfinding.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/19/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef HierarchicalPathfinding_hpp
#define HierarchicalPathfinding_hpp

#include <stdio.h>

/*
 
 Path is found in 2 phases
 
 1. High level room to room path is calculated
 2. Micro path to get the character to the next room is calculated. Once that is computed,
    the micro path to get the character to the next room to the goal, can be computed
    as each room is entered.If for some reason the character gets redirected, the remaining
    path is thrown away and never computed. 
 
 
 */



#endif /* HierarchicalPathfinding_hpp */
