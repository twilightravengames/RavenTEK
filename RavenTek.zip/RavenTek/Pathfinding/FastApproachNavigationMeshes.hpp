//
//  FastApproachNavigationMeshes.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/21/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef FastApproachNavigationMeshes_hpp
#define FastApproachNavigationMeshes_hpp

#include <stdio.h>
/* GAME GEM BOOK SECTION 3.7*/

#endif /* FastApproachNavigationMeshes_hpp */
