//
//  SqueezeAssert.hpp
//  NecroTek3D
//
//  Created by Walter Gress V on 12/2/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef SqueezeAssert_hpp
#define SqueezeAssert_hpp

#include <stdio.h>

/*
 
 Graphics Book 1 Section 1.12
 
 */

#endif /* SqueezeAssert_hpp */
