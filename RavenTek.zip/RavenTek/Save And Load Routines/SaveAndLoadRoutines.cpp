//
//  SaveAndLoadRoutines.cpp
//  RavenTek
//
//  Created by Walter Gress V on 12/20/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#include "SaveAndLoadRoutines.hpp"
#include <string>
#include <list>

using namespace std;

struct SaveObject;
enum save_type { INT, FLOAT, LONG, DOUBLE, STRING };

std::list<SaveObject> save_list;

struct SaveObject
{
    void *save_object;
    save_type type;
};


void AddSaveObject(void *save_object, save_type type)
{
    //add parameters to a SaveObject structure
    //add object to save list
    //when save is called, iterates through this list
    //and saves it to an xml file.
    //possible save targets are the xml map file,
    //the scenegraph (should be the same as the map file)
    //messages in the task manager, etc.
}

void Save()
{
    //iterates through the save list and saves the
    //data to an xml file
}

void Load()
{
    //iterates through the saved list from disk and
    //restores the task list
}

