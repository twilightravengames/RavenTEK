//
//  AuthenticationForOnlineGames.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/27/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef AuthenticationForOnlineGames_hpp
#define AuthenticationForOnlineGames_hpp

#include <stdio.h>
/* GAME GEMS BOOK 7 SECTION 6.2*/

#endif /* AuthenticationForOnlineGames_hpp */
