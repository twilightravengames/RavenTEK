//
//  Host.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/24/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef Host_hpp
#define Host_hpp

#include <stdio.h>
#include <vector>
#include "Client.hpp"
#include "Message.hpp"
#include "Entity.hpp"
class Host
{
public:
    std::vector<Client> client_list;
    
    //manages clients
    void add_clients();
    void remove_clients();
    void dispatch(std::vector<int> client_list);  //
    void  router(Message m, Entity e);
    Client get_clients(int index);
};
#endif /* Host_hpp */

