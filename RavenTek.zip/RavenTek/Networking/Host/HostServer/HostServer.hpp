//
//  HostServer.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/24/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef HostServer_hpp
#define HostServer_hpp

#include <stdio.h>
#include "Client.hpp"

class HostServer
{
public:
    Client spawned_client;
    void loop()
    {
        //sets this up as a blocking server socket
        //connects to the client
        //
        //populages the package list
        //dispatches: picks off a package and send it to the 
    }
    
    void client_socket_loop()
    {
        while(true)
        {
            //this loop sits on a thread waiting for a conectiomn tot his, (The host) The server
            //spawns a thread and continues
           
            send_package_to_all_clients();
            
        }        //
    }
    
    void send_package_to_all_clients()
    {
        //sends all packages to all clients
        
    }
};











#endif /* HostServer_hpp */
