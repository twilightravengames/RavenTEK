//
//  Host.cpp
//  RavenTek
//
//  Created by Walter Gress V on 12/24/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#include "Host.hpp"
#include "Client.hpp"

Client Host::get_clients(int index)
{
    return client_list[index];
}

void Host::router(Message m, Entity e)
{
    for (Client client : client_list)
    {
        //iterarting throguh clients
        //and passes message to every client's scheduler
        
    }
}

