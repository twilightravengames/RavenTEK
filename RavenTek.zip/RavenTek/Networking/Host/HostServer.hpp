//
//  HostServer.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/24/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef HostServer_hpp
#define HostServer_hpp

#include <stdio.h>
#include <list>
#include "Package.hpp"

//In a game, the lobby is where you chose a server
//to join,. That game is not only a host it acts a
//server for the game as well.

class HostServer
{
public:
    //IN
    std::list<Package> package_list;
        
    void insert_packages(Package package); //insert package into the network queue
                                            //the network queue resides in the host
                                            //
    
    void loop()
    {
        
    }
    
    //OUT
    void dispatch_message();        //picks off a package, send it to the network layer of
                                    //all the clients, and send it from the network layer
                                    //to the scheduler of each client
    
};





#endif /* HostServer_hpp */
