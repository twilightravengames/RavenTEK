//
//  RTSNetworkProtocol.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/21/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef RTSNetworkProtocol_hpp
#define RTSNetworkProtocol_hpp

#include <stdio.h>
/* GAME GEMS BOOKS 3 SECTION 5.2*/
#endif /* RTSNetworkProtocol_hpp */
