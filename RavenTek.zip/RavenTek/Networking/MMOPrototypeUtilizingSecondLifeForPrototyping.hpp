//
//  MMOPrototypeUtilizingSecondLifeForPrototyping.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/26/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef MMOPrototypeUtilizingSecondLifeForPrototyping_hpp
#define MMOPrototypeUtilizingSecondLifeForPrototyping_hpp

#include <stdio.h>
/* GAME GEMS BOOK 6 SECTION 7.4*/
#endif /* MMOPrototypeUtilizingSecondLifeForPrototyping_hpp */
