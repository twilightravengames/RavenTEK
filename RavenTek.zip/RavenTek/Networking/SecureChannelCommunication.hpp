//
//  SecureChannelCommunication.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/27/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef SecureChannelCommunication_hpp
#define SecureChannelCommunication_hpp

#include <stdio.h>
/* GAME GEMS BASE 8 SECTION 5./1*/
#endif /* SecureChannelCommunication_hpp */
