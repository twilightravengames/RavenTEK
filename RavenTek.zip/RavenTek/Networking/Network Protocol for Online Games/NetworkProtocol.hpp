//
//  NetworkProtocol.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/17/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef NetworkProtocol_hpp
#define NetworkProtocol_hpp

#include <stdio.h>
/* GEMS BOOK 1 SECTION 1.11*/
#endif /* NetworkProtocol_hpp */
