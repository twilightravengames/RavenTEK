//
//  NetworkLayer.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/24/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

/*
 
 Local Message gets queued
 Lecal Message is sent to scheduler
 if client, Network Messanger sends the message to the host
 if host, sends message to all clients
 
 
 */




#ifndef NetworkLayer_hpp
#define NetworkLayer_hpp

#include <stdio.h>
#include <list>
#include "Package.hpp"
#include "Client.hpp"

using namespace std;

class NetworkLayer
{
    //OUT
    list<Package> package_list;  //local network queue
    
    
   
    void dispatch_message(Client client);        //picks off a package, send it to the                                                  scheduler layer
                                        //of
                                      //all the clients, sendingit from the network layer
                                      //to the scheduler of each client
    
    
    //IN
    void add(Message m, Entity e)
    {
        //add the message and entity to the local network queue
        Package p;
        p.m = m;
        p.e = e;

        package_list.push_back(p);        //applies the message to all of the clients via the host
        
        
    }

    list<Package> getPackageList()
    {
        return package_list;
    }
    
/*   void setPackageList(list<Package> package_list)
    {
        package_list = this.package_list;
    }
  */
      
    void loop()
    {
        
    }
      
    
};
#endif /* NetworkLayer_hpp */
