//
//  NetworkLayer.cpp
//  RavenTek
//
//  Created by Walter Gress V on 12/24/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#include "NetworkLayer.hpp"
#include "HostServer.hpp"


void dispatch_message();        //picks off a package, send it to the network layer of
              //all the clients, and send it from the network layer

void NetworkLayer::dispatch_message(Client client)
{
    //picks ooff a package, send it to the scheduler on the remote client
     
    Package pkg = package_list.front();
    
    HostServer hs;
    hs.client_socket_loop();
    hs.send_package_to_all_clients();
    
    
}
