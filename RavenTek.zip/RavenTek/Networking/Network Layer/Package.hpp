//
//  Package.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/24/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef Package_hpp
#define Package_hpp

#include <stdio.h>
#include "Message.hpp"
#include "Entity.hpp"
#include "NetworkEnum.hpp"


class Package
{
public:
    Message m;
    Entity e;
    network_enum network_enum;
    
};
#endif /* Package_hpp */
