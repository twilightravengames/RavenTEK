//
//  NetworkEnum.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/24/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef NetworkEnum_hpp
#define NetworkEnum_hpp

#include <stdio.h>

enum network_enum
{
    NET_POSTURE,
    NET_MOVEMENT,
    NET_ACTION
};

#endif /* NetworkEnum_hpp */
