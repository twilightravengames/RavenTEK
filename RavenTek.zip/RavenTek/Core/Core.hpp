//
//  Core.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/20/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef Core_hpp
#define Core_hpp

#include <stdio.h>
#include "TaskManager.hpp"
#include "EventManager.hpp"
#include "Scheduler.hpp"
#include <thread>
#include "CoreLogic.hpp"
#include "ManualSampler.hpp"
#include "HostServer.hpp"
#include "SceneGraph.hpp"
#include "EntityFactory.hpp"
class Core;

//std::thread *ptrClockThread = 0;

/*
// Initialize static member of class Box
int Core::objectCount;
// Initialize static member of class Box
int Core::objectCount ;
// Initialize static member of class Box
int Core::objectCount;
// Initialize static member of class Box
int Core::objectCount;;
// Initialize static member of class Box
int Core::objectCount;
*/


static Clock ck;
static TaskManager tm;
static EventManager em;
static Scheduler sc;
static MessageManager mm;
static ManualSampler ms;
static SceneGraph sg;
static EntityFactory ef;
static HostServer hs;


class Core
{
public:
    
   void initialize(bool host)    //host
    {
        
   
        //cout << "Initializing CORE 1.0" << endl;
         
        //Clock ck;
        //ck.halted;
        std::thread clock_thread(&Clock::loop, &ck);
        clock_thread.detach();
        //ptrClockThread = &clock_thread;
        
        
        if (host == true)
        {
            std::thread host_thread(&HostServer::loop, &hs);
            host_thread.detach();
            
        }
        //99
        
        //TaskManager tm;
        //std::thread task_thread(&TaskManager::loop, &tm);
        //task_thread.detach();
        //99
        //EventManager em;
        std::thread event_thread(&EventManager::loop, &em );
        event_thread.detach();
        //
        //Scheduler sc;
        std::thread scheduler_thread(&Scheduler::loop, &sc);
        scheduler_thread.detach();
        
      //
        //MessageManager mm;
        //std::thread message_thread(&MessageManager::loop, &mm);
        //message_thread.detach();
        
        //Manual Sampler
        //ManualSampler mss;
      
        std::thread manual_thread(&ManualSampler::loop, &ms);
        manual_thread.detach();
        //ms.loop();
      
        //TEST THREAD OBJECT
        
        
    }
    
    //Game Loop
    void update_loop()
    {
        while(true)
        {
            
        }
    }

public:
   
        
};








#endif /* Core_hpp */
