//
//  InitializeCore.cpp
//  RavenTek
//
//  Created by Walter Gress V on 12/20/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#include "InitializeCore.hpp"

/*
 This file initializes on threads MessageManager, Evcent Manager, and Task Manager.
 Initializes CORE files
 
 */
