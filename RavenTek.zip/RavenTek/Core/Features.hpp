//
//  Features.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/28/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//
//A class that maintains what engine features are enabled.
//this is set in the editor and carried over to the real-time game



#ifndef Features_hpp
#define Features_hpp

#include <stdio.h>

#endif /* Features_hpp */
