//
//  CoreLogic.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/21/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef CoreLogic_hpp
#define CoreLogic_hpp


#include <stdio.h>

#include "Scheduler.hpp"
#include "MessageManager.hpp"
#include "Clock.hpp"
#include "TaskManager.hpp"
#include "EventManager.hpp"



class CoreLogic
{
public:
    static TaskManager taskManager;
    static EventManager eventManager;
    static Scheduler scheduler;
    static MessageManager messageManager;
    //static Sampler sampler;
    static Clock clock;

};

#endif /* CoreLogic_hpp */
