//
//  EntityFactory.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/29/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef EntityFactory_hpp
#define EntityFactory_hpp
#include "Message.hpp"
#include "BaseEntity.hpp"
#include "Entity.hpp"
#include "EmptyPawn.hpp"
#include "WalkingEntity.hpp"
#include "IntelligentEntity.hpp"
#include "PlayerCharacter.hpp"
#include "StaticMesh.hpp"
#include <vector>
#include "Advisor.hpp"

#include <stdio.h>
class EntityFactory
{
public:
    void add(Message m, BaseEntity e);
    void add(Message *m, BaseEntity *e);
    void add(Message m, Entity e);
    void add(Message m, EmptyPawn p);
    void add(Message m, WalkingEntity w);
    void add(Message m, IntelligentEntity ie);
    void add(Message m, PlayerCharacter pc);
    void add(Message m, StaticMesh sm);
    
};
#endif /* EntityFactory_hpp */

