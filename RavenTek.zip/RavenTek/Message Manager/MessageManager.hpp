//
//  MessageManager.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/19/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef MessageManager_hpp
#define MessageManager_hpp

#include <stdio.h>
#include <queue>
//#include "Message.hpp"
#include "Entity.hpp"
#include <iostream>
#include "Arbiter.hpp"
#include "MessageEnums.hpp"
#include "BaseEntity.hpp"
#include "Entity.hpp"
#include "WeaponEntity.hpp"
#include "WalkingEntity.hpp"
#include "IntelligentEntity.hpp"
#include "EmptyPawn.hpp"
#include "PlayerCharacter.hpp"
#include "StaticMesh.hpp"
#include "MessageEnums.hpp"
#include "Scheduler.hpp"

using namespace std;
//queues and deques messages


/* Entities are FSMS. FSMs operate on input messages. FSMs only operate on Messages
 when its their turn. */


class MessageManager
{
public:
    
    void remove(Message m);
    void remove(Entity e);
    vector<Advisor> arbitration_list;
    //Message retrieve(Message m);
    //queue<Entity> entity_collection;
    //void update(Entity e, Message m);
    
    //std::queue<Message> Message get_msg_pipeline();
    //arbitationer.arbitrate(queue<Message> arbitration_list); //the updated message pipeline
    
    //void Update(Entity e, Message m);
    
    

    
    void loop()
    {
        cout << "Initializing MessageManager thread" << endl;
        while(true)
        {
            //add() has created an advisor and put it on the
            //arbitration_list
            //perform the arbitration and decide on an advisor
            //execute the arbitration results
            Arbiter ab;
            Advisor v = ab.decide();
            
           // Core.c.add(v.m, v.e);
            
            //cout << "Addding advisor to scheduler" << endl;
            
            //add(advisor.e, advisor.m); (in the network layer - only if flagged as host
                                          
        }
    }
};
    
    
    
    
    //advisors are in the msg_pipeline
    //arbiter decides the message that is priority
    //advisors are independent from each other]\
    //CHooses message and sends it off....
    //Sends message to scheduler. EventManager //(scheduler) creates a task and wraps the
                                        //message in an event. Then the event is wrapped in
                                        //a task and put in the queue according to time
                                        //and priority
          
/*
    enum kind_of_union
               {U_ENTITY,
                U_BASE_ENTITY,
                U_WEAPON_ENTITY,
                U_WALKING_ENTITY,
                U_INTELLIGENT_ENTITY,
                U_EMPTY_PAWN,
                U_PLAYERCHARACTER,
                U_STATIC_MESH
               };
    union EntityUnion{
        BaseEntity be;
        Entity e;
        WeaponEntity we;
            //WalkingEntity wk;
            //IntelligentEntity ie;
            //EmptyPawn ep;
            //PlayerCharacter pc;
            //StaticMesh sm
    };


    */
    
    
    //};

/*
 Message Manager
 ===============
 
 All objects in the game inherit from the Entity class. Each entity class has multiple states,
 essentially a finite state machine. FOr example, say the ANALOG_RIGHT message is received by
 the Game Input Entity. The ANALOG_RIGHT message is put into the message pipeline - a
 priority queue. When the message comes up in the queue, the router takes the message and
 routes it to the appropriate entity. The entity then, being a FSM as well, executes whatever
and where-ever. 
 
 The message manager sits on top of a thread seperate from the game, which sits on another
 thread. The entities sit on a thread as well. The MessageManager requests a thread from
 the scheduler for each entity when it is created. Instead of just dispatching the thread, the message is passed to the Scheduler to coordinate time of executionm, etc.
 */





#endif /* MessageManager_hpp */
