//
//  Message.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/19/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef Message_hpp
#define Message_hpp

#include <stdio.h>
#include "InputEnums.hpp"
#include "GameplayEnvironmentEnums.hpp"
#include "ClassEnums.hpp"
#include "BasicEnums.hpp"
#include "AdvancedEnums.hpp"
#include "NetworkEnums.hpp"
#include "DebugEnums.hpp"
#include <iostream>
#include "TimeBlock.hpp"


using namespace std;

class Message
{
public:
    
    //enums - 0 is not set
    
    Message()
    {
        cout << "clas Message constructed" << endl;
    }
    
    PlayerInputEnum EV_input_event;    //messages input from player
    gameplay_environment_enum EV_physics_event;  //physics in the game
    
    class_enums EV_roadcast_event;
    //sends a broadcast message to all the entities in the game
    
    basic_enums EV_basic_data_event;
    //sends a message of characters basic properties
    
    advanced_enums EV_advanced_event;
    //more advanced enums
    
    network_enums EV_networking_event;
    //basic network messages
    
    debug_enums EV_debug_event;
    
    
    
    //void * pEntityType;
    
    TimeBlock tb;   ///scheduling
    
    void* payload;    //dependent upon the event type. will look at this pointer
                       //for payload information
    int priority;   //used to calculate scheduling. 0 is immediately , 5 is slower, etc.
};








#endif /* Message_hpp */
