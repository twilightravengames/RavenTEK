//
//  UnionBase.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/30/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef UnionBase_hpp
#define UnionBase_hpp

#include <stdio.h>
#include "BaseEntity.hpp"
/*
#include "EmptyPawn.hpp"
#include "WeaponEntity.hpp"
#include "WalkingEntity.hpp"
#include "IntelligentEntity.hpp"
#include "PlayerCharacter.hpp"
#include "StaticMesh.hpp"
*/

//
//typedef union union_base union_base;


/* class votes to be the one to be picked*/
union union_base {
    BaseEntity baseEntity;
    //Entity actorEntity;
    //EmptyPawn emptyPawn;
    //WeaponEntity weapon;
    //WalkingEntity walkingEntity;
    //IntelligentEntity intelligentEntity;
    //PlayerCharacter playerCharacter;
    //StaticMesh staticMesh;
    ~union_base();
};


#endif /* UnionBase_hpp */
