//
//  GameplayEnvironmentEnums.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/21/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef GameplayEnvironmentEnums_hpp
#define GameplayEnvironmentEnums_hpp

#include <stdio.h>

//PHYSICS

enum gameplay_environment_enum {
    
    EM_FORCE,   //An explosion entity could broadcast FORCE to the world
                //entities respond by calculating the effect of the force descrihbed
                //in the message
    EM_DAMAGE,  //When a projectile strikes a target, it sends a damage message
                //telling the recipient how many hit poi nts of damage it wants to impart
    EM_GIVEPOINTS //When an entity is destroyed, it can give points to the owner of the
                    //projectile that destroyed it
    
};







#endif /* GameplayEnvironmentEnums_hpp */
