//
//  AdvancedEnums.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/21/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef AdvancedEnums_hpp
#define AdvancedEnums_hpp

#include <stdio.h>



enum advanced_enums {
    EM_DRAWOVERLAY,     //Certain entites might want to draw after the main rendering such
                        //as a halo or a ring around the moon
    EM_DRAWSHADOW,      //Similarly, some shadow algorithms are done post processing
    
    EM_SETOWNER,        //If the entity tree is used as a scene graph
    
    EM_IMDEAD           //Sometimes it is useful to broadcast that an entity is dead
                        //for example, so an enemy ceases chasing that entity
};



#endif /* AdvancedEnums_hpp */
