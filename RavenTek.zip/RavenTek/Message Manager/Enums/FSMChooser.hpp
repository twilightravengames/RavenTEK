//
//  FSMChooser.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/25/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef FSMChooser_hpp
#define FSMChooser_hpp

#include <stdio.h>

//a list of possible entities for the factory to return

enum factory_prodcued {
    POINT_LIGHT,
    CUBE_PRIMITIVE,
    ACTOR,
    PAWN,
    PRIMITIVE,
    CHARACTER,
    SPOTLIGHT,
    AMBIENT_LIGHT,
    CAMERA,
    CHASE_CAMERA
};




#endif /* FSMChooser_hpp */
