//
//  InputEnums.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/19/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef InputEnums_hpp
#define InputEnums_hpp

#include <stdio.h>




enum PlayerInputEnum
{
   
    SHOULDER_LEFT,
    SHOULDER_RIGHT,
    SHOULDER_LEFT_2,
    SHOULDER_RIGHT_2,
    A_BUTTON,
    B_BUTTON,
    C_BUTTON,
    D_BUTTON,
    START_BUTTON,
    SELECT_BUTTON,
    ANALOG_LEFT,
    ANALOG_RIGHT,
    D_PAD_UP,
    D_PAD_DOWN,
    D_PAD_LEFT,
    D_PAD_RIGHT
};

enum PlayerPCInputEnum
{
    W_PRESS,
    A_PRESS,
    S_PRESS,
    D_PRESS,
    ENTER,
    SPACE,
    MOUSE_MOVEMENT,
    MB_LEFT,
    MB_RIGHT,
    MB_CENTER
};




#endif /* InputEnums_hpp */
