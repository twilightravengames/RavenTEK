//
//  NetworkEnums.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/21/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef NetworkEnums_hpp
#define NetworkEnums_hpp

#include <stdio.h>


enum network_enums
{
    EM_SERVERUPDATE,        //Server nodes send this to handle AI, decision-making
                            //and position updating.  ALso to synchronize between multiple
                            //servers.
    EM_CLIENTUPDATE,        //Sent instead of the normal EM_UPDATE to allow client nodes
                            //to dead-reckon their entities, without performing any AI
                            //or dynamics
    EM_NETPROCESS,          //As the game loop receives network traffic, this distributes
                            //packets destined for individual entities via NETPROCESS
    
    EM_POSTURE,             //how a character appears in the world, including states such as,
                            //standing upright, swimming, hovering, or riding a mount
    
    EM_MOVEMENT,            //motion of a character in the game world, state for each
                            //movcement direction, forward, backward, left, right,
                            //stop state for when at rest
    
    EM_ACTION               //various in-game behaviors a character can perform,
                            //these can potentially independently of the staters in the
                            //other two layers. For example a character could be swimming
                            //while attacking a creature with a weapon
    
};





#endif /* NetworkEnums_hpp */
