//
//  GameEnums.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/19/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef GameEnums_hpp
#define GameEnums_hpp

#include <stdio.h>


enum game_enums
{
    EM_TESTHIT,     //Requests the recipient performs a "hit test".
    
    EM_IHITYOU      //Returns the hit test results to the sender
    
    
};


#endif /* GameEnums_hpp */
