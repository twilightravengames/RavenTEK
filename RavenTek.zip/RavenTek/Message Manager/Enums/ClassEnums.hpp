//
//  ClassEnums.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/21/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef ClassEnums_hpp
#define ClassEnums_hpp

#include <stdio.h>


enum class_enums {
    EM_CLSINIT,     //Sent once to every entity in the game.
                    //upon receiving classes can load resources from disk
                    //set up class wide static variables,
    EM_CLSFREE,     //Class releases any resources it loaded and free any allocated
                    //memory
    EM_CLSNAME      // Returns the name of the class. This provides the class list
                    // with the class's name and supports the rare case where an entity
                    // might need to know who it is communicating with
};

#endif /* ClassEnums_hpp */
