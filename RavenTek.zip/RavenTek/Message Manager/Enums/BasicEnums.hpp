//
//  BasicEnums.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/21/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef BasicEnums_hpp
#define BasicEnums_hpp

#include <stdio.h>



enum basic_enums
{
    EM_CREATE,          //An entity receives the create message immediately after
                        //its container has been created by the entity manager
                        //The entity allocates the memory it needs for its internal
                        //data and initializes any default values.
    EM_SET_DIR,
    EM_SET_VELOCITY,
    EM_SET_YAW,
    EM_SETCOLOR,        /* ACCESSORS AND MUTATORS FOR ENTITY DATA*/
    
    EM_GET_DIR,
    EM_GET_VELOCITY,
    EM_GET_YAW,
    EM_GET_COLOR,
    
    EM_START,               //Once the entity is created, positioned, and set up it is sent
                            //this message
    EM_DESTROY,             //Demands immediate destrucetion of the entity DESTROY gives an
                            //entity the chance to clean up
    
    EM_SHUTDOWN,             // Allows the destruction of the entity gracefully
    EM_DRAW,                //Entities respond to this by rendering themselves in the world
    EM_UPDATE,              //Gives an entity the chance to update its position in the world.
                            //The elapsed time sinvce the last frame would be passed as a
                            //parameter to this message.
    
    
    EM_POSTUPDATE,          //Cerrtain operations like collision detecftion and AI
                            //need to know the "new" state of the world after all
                            //entities have been updated. A message like POSTUPDATE is
                            //typically sent to the world just after all entities have
                            //processed UPDATE
    EM_USERINPUT            //IUsed to send input device events or state updates to the
                            //entities currently controlled by the player.
};


#endif /* BasicEnums_hpp */
