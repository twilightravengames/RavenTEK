//
//  DebugEnums.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/22/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef DebugEnums_hpp
#define DebugEnums_hpp

#include <stdio.h>

enum debug_enums {
    EM_DEBUGDRAW,           //entities respond to this by drawing their debugging info
    EM_EDITDRAW,            //tells the entity to respond in 'edit' mode.  For example
                            //the game goes into a mode where one can change hit points
                            //or hot load an asset.
    EM_GETVARIABLE          //Exposes a table on screen of the current variables and their
                            //values
};



#endif /* DebugEnums_hpp */
