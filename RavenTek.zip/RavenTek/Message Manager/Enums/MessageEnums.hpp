//
//  MessageEnums.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/19/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef MessageEnums_hpp
#define MessageEnums_hpp

#include <stdio.h>


enum entity_switch
{
    BASE_ENTITY,
    ENTITY,
    WEAPON_ENTITY,
    WALKING_ENTITY,
    INTELLIGENT_ENTITY,
    EMPTY_PAWN,
    PLAYERCHARACTER,
    STATIC_MESH
};


#endif /* MessageEnums_hpp */
