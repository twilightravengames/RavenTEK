//
//  EntityFactory.cpp
//  RavenTek
//
//  Created by Walter Gress V on 12/29/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#include "EntityFactory.hpp"
#include "BaseEntity.hpp"
#include "Advisor.hpp"
#include "Entity.hpp"
#include "EmptyPawn.hpp"
#include "WalkingEntity.hpp"
#include "IntelligentEntity.hpp"
#include "PlayerCharacter.hpp"
#include "StaticMesh.hpp"
#include "Advisor.hpp"
#include <vector>
#include "MessageManager.hpp"

using namespace std;

 void EntityFactory::add(Message *m, BaseEntity *e)
{

    //entry point to the message manager
    Advisor advisor;
       
    advisor.m =  m;
    advisor.e = e;
    
    MessageManager mm;
    vector<Advisor> arb_list = mm.arbitration_list;
        
    arb_list.push_back(advisor);
    //push m&e to the arbiration_list to be handled by the message manager

 }


void EntityFactory::add(Message m, EmptyPawn p)
{
}

void EntityFactory::add(Message m, WalkingEntity w)
{
}

void EntityFactory::add(Message m, IntelligentEntity ie)
{
}
void EntityFactory::add(Message m, PlayerCharacter pc)
{

}

void EntityFactory::add(Message m, StaticMesh sm)
{
}


