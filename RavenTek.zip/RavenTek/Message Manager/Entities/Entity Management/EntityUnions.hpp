//
//  EntityUnions.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/26/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef EntityUnions_hpp
#define EntityUnions_hpp

#include <stdio.h>
#include "BaseEntity.hpp"
#include "Entity.hpp"
#include "WeaponEntiity.hpp"
#include "WalkingEntity.hpp"
#include "IntelligentEntity.hpp"
#include "EmptyPawn.hpp"
#include "PlayerCharacter.hpp"
#include "StaticMesh.hpp"
#include "MessageManager.hpp"




            enum kind_of_union
            {U_ENTITY,
             U_BASE_ENTITY,
             U_WEAPON_ENTITY,
             U_WALKING_ENTITY,
             U_INTELLIGENT_ENTITY,
             U_EMPTY_PAWN,
             U_PLAYERCHARACTER,
             U_STATIC_MESH
            };
     union EntityUnion{
         BaseEntity be;
         Entity e;
         WeaponEntity we;
         WalkingEntity wk;
         IntelligentEntity ie;
         EmptyPawn ep;
         PlayerCharacter pc;
         //StaticMesh sm


#endif /* EntityUnions_hpp */

