//
//  Arbiter.cpp
//  RavenTek
//
//  Created by Walter Gress V on 12/23/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#include "Arbiter.hpp"



Advisor Arbiter::decide()
   {
       
       //goes through advisors and decides upon one
       Advisor ad;
       for (int i = 0; i<arbitration_list.size(); i++)
       {
           if (arbitration_list[i].weight > ad.weight)
           {
               ad = arbitration_list[i];
           }
       }
       return ad;
   }
