//
//  BaseEntity.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/25/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.


#ifndef BaseEntity_hpp
#define BaseEntity_hpp

#include <stdio.h>

#include "Message.hpp"
#include "SceneGraphNode.hpp"



class BaseEntity : public SceneGraphNode
{
public:
     void dispatch(Message *msg);  //executes a finite state machine
                                    //"event" over a message "msg"
                                    //when scheduler gives the "fire" signal
    
      void notify();                     //notifies the dynamic BSP that a                                      //change occurred to
                                         //the mesh and it has to rebalance
                                            //in this case you can use FLINCH //in place of the plain vanilla //finite state machine
     
    void loop();
};
#endif
