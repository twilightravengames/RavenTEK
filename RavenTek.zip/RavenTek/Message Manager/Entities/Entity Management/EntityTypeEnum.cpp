//
//  EntityTypeEnum.cpp
//  RavenTek
//
//  Created by Walter Gress V on 12/25/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#include "EntityTypeEnum.hpp"

//enum to direct which factory thing is produced

enum entity_types
{

 SC_ENTITY,
 SC_WEAPON_ENTITY,
 SC_WALKING_ENTITY,
 SC_INTELLIGENT_ENTITY,
 SC_EMPTY_PAWN_ENTITY,
 SC_PLAYER_CHARACTER_ENTITY,
 SC_STATIC_MESH_ENTITY
};
