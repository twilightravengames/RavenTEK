//
//  Advisor.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/23/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef Advisor_hpp
#define Advisor_hpp

#include <stdio.h>
//
//#include "MessageEnums.hpp"
 
#include "BaseEntity.hpp"
#include "Message.hpp"
#include "TimeBlock.hpp"
/* GAME GEMS BOOK 4 SECTION 4.5'*/

//advisors are messages delivered to the arbiter for decision
//of which message in the queue to execute



class Advisor
{
public:
    
    /*
    Advisor(Message &msg, BaseEntity &ent) : m(msg),e(ent)
    {
    }
    
    
    Advisor(const Advisor &ad): e(ad.e), m(ad.m)
    {
        e = ad.e;
        m = ad.m;
       
    }
    */
    
    
    Message *m;
    //?datatype event (a fsm)
    BaseEntity *e;
    TimeBlock timeBlock;
    
  
    float weight;
    

    
};


#endif /* Advisor_hpp */
