//
//  Arbiter.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/23/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef Arbiter_hpp
#define Arbiter_hpp
#include "Advisor.hpp"
#include <stdio.h>
#include <queue>
#include <vector>
/* GAME GEMS BOOK 4 SECTION 4.5'*/

class Arbiter
{
public:
    Advisor decide();
    vector<Advisor> arbitration_list;
    //goes through the advisors and decodes which advisor(s) to send
    //to the scheduler
};


#endif /* Arbiter_hpp */
