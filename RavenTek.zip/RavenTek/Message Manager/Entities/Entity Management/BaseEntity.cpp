//
//  BaseEntity.cpp
//  RavenTek
//
//  Created by Walter Gress V on 12/25/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#include "BaseEntity.hpp"
//#include "Entity.hpp"
#include <iostream>
void BaseEntity::dispatch(Message *msg)
{
    cout << "Dispatching BaseEntity" << endl;
    switch(msg->EV_input_event)
      {
          case SHOULDER_LEFT:
              break;
          case SHOULDER_RIGHT:
              break;
          case SHOULDER_LEFT_2:
              break;
          case SHOULDER_RIGHT_2:
              break;
          case A_BUTTON:
              break;
          case B_BUTTON:
              break;
          case C_BUTTON:
              break;
          case D_BUTTON:
              break;
          case START_BUTTON:
              break;
          case SELECT_BUTTON:
              break;
          case ANALOG_LEFT:
              break;
          case ANALOG_RIGHT:
              break;
          case D_PAD_UP:
              break;
          case D_PAD_DOWN:
              break;
          case D_PAD_LEFT:
              break;
          case D_PAD_RIGHT:
              break;

    
      }
 

}


void BaseEntity::notify()
{
    
}

void BaseEntity::loop()
{
    
}

   
