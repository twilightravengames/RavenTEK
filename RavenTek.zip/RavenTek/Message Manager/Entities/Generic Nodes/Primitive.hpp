//
//  Primitive.hpp
//  NecroTek3D
//
//  Created by Walter Gress V on 12/1/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef Primitive_hpp
#define Primitive_hpp

#include <stdio.h>

#endif /* Primitive_hpp */
