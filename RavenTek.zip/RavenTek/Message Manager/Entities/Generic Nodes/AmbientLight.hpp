//
//  AmbientLight.hpp
//  NecroTek3D
//
//  Created by Walter Gress V on 12/1/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef AmbientLight_hpp
#define AmbientLight_hpp

#include <stdio.h>

#endif /* AmbientLight_hpp */
