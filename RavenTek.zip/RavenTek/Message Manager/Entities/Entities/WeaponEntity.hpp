//
//  WeaponEntiity.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/25/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef WeaponEntiity_hpp
#define WeaponEntiity_hpp

#include <stdio.h>

#include "Entity.hpp"


class WeaponEntity : public Entity
{
    float durability = 100; //percent, higher number better durapility
    float damage = 10;      //score range from 0 to 100;
    
};


#endif /* WeaponEntiity_hpp */
