//
//  EmptyPawn.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/19/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef EmptyPawn_hpp
#define EmptyPawn_hpp

#include <stdio.h>

#include "StaticMesh.hpp"
#include "Entity.hpp"
#include "Point3D.hpp"




class EmptyPawn : public Entity
{
    Point3D center;
    float width;
    float height;
    StaticMesh model;
};


#endif /* EmptyPawn_hpp */
