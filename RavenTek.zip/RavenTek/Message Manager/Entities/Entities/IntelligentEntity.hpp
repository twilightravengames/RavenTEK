//
//  IntelligentEntity.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/19/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef IntelligentEntity_hpp
#define IntelligentEntity_hpp

#include <stdio.h>
#include "CAIBrain.hpp"
#include "WalkingEntity.hpp"
#include "FLINCH.hpp"


class IntelligentEntity : public WalkingEntity
{
public:
    CAIBrain  brain;
    //every intelligent entity has a FLINCH tree
    FLINCH flinch_tree;
};


#endif /* IntelligentEntity_hpp */
