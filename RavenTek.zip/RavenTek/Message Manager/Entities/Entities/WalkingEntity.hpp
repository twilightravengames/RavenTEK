//
//  WalkingEntity.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/19/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef WalkingEntity_hpp
#define WalkingEntity_hpp

#include <stdio.h>

#include "EmptyPawn.hpp"
#include "Vec3D.hpp"
#include "Point3D.hpp"



class WalkingEntity  : public EmptyPawn
{
    Vec3D trajectory;
    Point3D current_point;
};




#endif /* WalkingEntity_hpp */
