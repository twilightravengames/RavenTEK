//
//  PlayerCharacter.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/20/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef PlayerCharacter_hpp
#define PlayerCharacter_hpp

#include <stdio.h>
#include "IntelligentEntity.hpp"
#include "Vec3D.hpp"
#include "Point3D.hpp"

class PlayerCharacter : public IntelligentEntity
{
public:
   //a special entity controlled by the player
    
    //players dimensions
    int center_x;
    int center_y;
    int center_z;
    int width;
    int height;
    int depth;
    
    int current_animation; //current animation being performed
    
    Vec3D travelling; //a 3D vector indicating direction (i,j,k) and speed
                        // and magnitude
    Point3D current_point;
    
    
};


#endif /* PlayerCharacter_hpp */
