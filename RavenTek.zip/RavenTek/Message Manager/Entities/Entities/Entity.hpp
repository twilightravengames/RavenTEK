//
//  Entity.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/19/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef Entity_hpp
#define Entity_hpp

#include <stdio.h>

#include "BaseEntity.hpp"

/*
 Entities can be swapped with other entities. This is the base entity
 
 
 */


class Entity : public BaseEntity
{
public:
    void dispatch(Message *msg);     //see message manager for instructions
                                    //class entity is the foundation of messenger
                                    //dispatch processes in the Finite State Machine
    void notify();                     //notifies the dynamic BSP that a change occurred to
                                        //the mesh and it has to rebalance
    //in this case you can use FLINCH in place of the plain vanilla finite state machine
    
    
    //entity is generated
    
    //factory returns an entity type
    //entity type is assigned to Message
    
    
    
};





#endif /* Entity_hpp */
