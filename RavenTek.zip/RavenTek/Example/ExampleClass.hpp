//
//  ExampleClass.hpp
//  NecroTek3D
//
//  Created by Walter Gress V on 12/2/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef ExampleClass_hpp
#define ExampleClass_hpp

#include <stdio.h>

class ExampleClass
{
public:
    ExampleClass()      { Clear(); }
    ~ExampleClass()     { Destroy(); }
    
    
    void Clear();
    
    bool Create();      //step function
    void Update();      //initializes variables
    void Destroy();     //frees memory
};







#endif /* ExampleClass_hpp */
