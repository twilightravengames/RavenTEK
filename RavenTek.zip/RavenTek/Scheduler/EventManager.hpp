//
//  EventManager.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/20/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef EventManager_hpp
#define EventManager_hpp

#include <stdio.h>
#include "Message.hpp"
#include "Event.hpp"
#include <queue>
#include <iostream>
#include "Task.hpp"
#include "TaskManager.hpp"

/* GAME GEMS BOOK 3 SECTION 1.1*/

/*
 The Event Manager is the heart of the scheduler. Each task in the task manager
 defines one or more events that it handles. An event is a moment in time
 when a task is to be executed. The event manager generates events as needed
 to trigger the execution of tasks.
 
 
 */
using namespace std;

class EventManager
{
public:
   
    
    void add(Event e)       //add Event to Event Queue
    {
        events_queue.push(e);
    }
    void remove(Event e);
    Event retreive(Event e);
    void update();          //
    void calculate_fire_time();
    void add(Message &m, Entity &e); //constructs an event and adds it to the events_queue
    
    void run();
    void stop();            //flags as halted, blocks remove function from manager
    
    void loop()
    {
        //cout << "Initializing Event Manager Thread" << endl;
        while (true)
        {
            
        }
    }
    
    Task poll();
    
    
    private:
    bool halted;
    queue<Event> events_queue;
    
    Event wrap_event(Message &msg, Entity &e);
         
};



#endif /* EventManager_hpp */
