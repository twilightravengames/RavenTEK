//
//  Scheduler.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/20/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef Scheduler_hpp
#define Scheduler_hpp

#include <stdio.h>
#include "Clock.cpp"
#include "Entity.hpp"
#include "Message.hpp"
#include <iostream>
#include "Advisor.hpp"
#include "PlayerCharacter.hpp"
#include "TaskFactory.hpp"
#include "Task.hpp"
#include "WeaponEntity.hpp"
#include "WalkingEntity.hpp"
#include "IntelligentEntity.hpp"
#include "EmptyPawn.hpp"
#include "StaticMesh.hpp"
#include "TaskManager.hpp"
#include "Arbiter.hpp"
#include "Message.hpp"
#include "BaseEntity.hpp"
#include "EventManager.hpp"


using namespace std;

class Scheduler
{
public:
    Scheduler()
    {
        //cout << "Constructing Scheduler object" << endl;
    }
    Clock clock();
    
    void executeFrame();  //each time this method is called it first calls                              //clock.beginframe
                        //which starts a new frame by updating the frame count and
                        //and computing new frame start and end times.
                        //  After updating the frame count, it executes all time events,
                        // advances the simulation time to the end of the frame,
                        // executes all frame events, then finally executes FINISH
                        // event.
    
    
                        // Frame Events are simple and occur once per N frames
                        //  or every frame
    
                        // Time Events occur in simulation time and are not necessarily
                        // synchronized with any specific time frame. For exmple a
                        // event can occur every 10ms regardless of the rendering frame rate
                        // It is possible to combine Time Events and Frame Events
                        // For example, an event could be scheduled to occur 10 ms after
                        // every frame.  or it could edxecute five times per frame, evenly
                        // distributed
    
    void run();              //Restart the simulation calls EventManager and TaskManager
    void stop();             //Stop the simulation - calls EentManager and TaskManagfer
    void update();           //runs the task manager one cycle - calls Event Manager and
                            //TaskManager
public:
    
//#1
    void add(Message *m, BaseEntity *be);
    
 //adds a message and entity wrapped as an advisor from the message pump and
                                    //run TaskFactory to get a task then queue it in the Taskmanager
   //void add() adds the task to the task_list
    //
  
    void arbitrate(Message m, BaseEntity be); //decide on what  taks to execute
    
public:
    
    void loop()
    {
        //cout << "Intializing Scheduler Thread" <<  endl;
        while(true)
        {
            
        }
    }
    

    Event wrap_event( Message *m , BaseEntity *e);
};


struct clock_params
{
    
};

struct task_manager_params
{
    
};

struct event_manager_params
{
    
};

struct scheduler_params
{
    
};

struct message_manager_params
{
    
};

struct manual_sampler_params
{
    
};

struct scene_graph_paramws
{
    
};

struct entity_factory_params
{
    
};

struct host_server_params
{
    
};








#endif /* Scheduler_hpp */
