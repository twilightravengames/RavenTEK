//
//  TaskFactory.cpp
//  RavenTek
//
//  Created by Walter Gress V on 12/20/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//



#include "Entity.hpp"
#include "Task.hpp"
#include "Event.hpp"
#include "Task.hpp"
#include "TaskFactory.hpp"
#include "TaskManager.hpp"

//#4
Task TaskFactory::wrapTask(Message *m, BaseEntity *e)
{
    Task task;
    
    Event event;
    event = event.wrap_message(m, e); //#5
    TaskManager t_m;
    task = t_m.wrap_event_in_task(event);  //#7
    return task;        //Task encapsulating event message & event data members
}
