//
//  TaskFactory.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/20/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef TaskFactory_hpp
#define TaskFactory_hpp

#include <stdio.h>
#include "Task.hpp"
#include "BaseEntity.hpp"

class TaskFactory
{
public:    //#4
    Task wrapTask(Message *m, BaseEntity *e);
                                            
};


#endif /* TaskFactory_hpp */
