//
//  Clock.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/20/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef Clock_hpp
#define Clock_hpp

#include <stdio.h>

#include <queue>
#include "TimeBlock.hpp"
#include "Task.hpp"
#include <iostream>
#include "TimeBlock.hpp"
/* GAME GEMS BOOK 3 SECTION 1.1*/
/*
 
 Handles the registration and organization of tasks.
 Each task has a standardized interface contains a callback
 function for the manager to execute.
 
 //virtual time scheduler divides time into frames.
 //Tasks are executed in batches between frames running in virtual time
 //then synchronized with real time when each frame is rendered
 //If simulation time stops, the rest of the application stops as well
 //should be able to resume action after stopping without change
 */
using namespace std;
 class Clock
 {
 public:
     int frame_counter;
     double real_time;
     double virtual_time;
     int frame_size = 100;
     int default_frame_size = 300;
     bool halted = true;  //stop the clock
     
     //request_size dealt with the frame_size member variable
     TimeBlock getFrame(TimeBlock)
     {
         
         
         for (TimeBlock tb : time_blocks)
         {
                if (tb.task_size < default_frame_size)
                {
                    //it will fit.
                    TimeBlock newtimer;                    time_blocks.push_back(newtimer);
                }
         }
         
         
         TimeBlock tb = time_blocks.front();
         time_blocks.pop_front();
         
         return tb;
     }
     
     
     std::list<TimeBlock> time_blocks;
     //dimensions of time blocks  and their positions in the clcok
     
     void loop()
     {
         //cout << "Initializing Clock thread" << endl;
         while(true)
         {
             frame_counter++;
             //check to see if its time for the task to fire
             //check to see if
             //if so, remove the time block
             //and put the funcction on a thread
             
             //allocating frame
             //determine how much time is needed
             //allocate fast forward iterating one by one
             //like a sliding window, looking to see if
             //there is enough time. if so then intsantiate
             //a TimeBlock for that time size and
             //the begin and end clock time
             
         }
     }
     
     int deal_time(); //deals out frame time.
     
     void check_time(Task t); //Step 1: See if the task can fit in the frame
                              //Step 2: If it can, add it to the worker threads
 };
 
#endif /* Clock_hpp */
