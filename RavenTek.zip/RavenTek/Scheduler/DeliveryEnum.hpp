//
//  DeliveryEnum.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/19/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef DeliveryEnum_hpp
#define DeliveryEnum_hpp

#include <stdio.h>

//each state is put on its own thread
enum DeliveryEnum //Each enum has as part of its payload how long it takes to fire
{
        RENDER_SCENE,
        CHECK_FOR_INPUT,
        UPDATE_ANIMATION,
        COLLISION_DETECTION,
        PHYSICS_UPDATE,
        PROCESS_SCENEGRAPH, //call Update() methods on scenegraph
        ARTIFICIAL_INTELLIGENCE,   // Only has to run every couple seconds or so
        CAIBEHAVIOR             //High level behaviors with embedded entities
};


#endif /* DeliveryEnum_hpp */
