//
//  Scheduler.cpp
//  RavenTek
//
//  Created by Walter Gress V on 12/20/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#include "Scheduler.hpp"


/*
void Scheduler::add(Message m, PlayerCharacter pc)
{
    //call on task factory
    //enqueue task to taskmanager
    TaskFactory tf;
    
    //Task task = tf.wrapTask(m, *base);
}

void Scheduler::add(Message m, BaseEntity be)
{
    
}

void Scheduler::add(Message m, Entity e)
{
    
}

//#2
//void Scheduler::add(Message *m, BaseEntity *be)
//{
//    cout << "Adding a message and entity pair to scheduler" << endl;
//    //call on task factory
//    //enqueue task to taskmanager
//    cout << "Cfreating TaskFactory and wrapping m,be into a task" << endl;
//    TaskFactory tf;  //#3
//    Task task = tf.wrapTask(m,be);
//
//    TaskManager tm;
//    tm.add(task);
//    //cout << "Creating task manager and pushing task into Task_list" << endl;
//    //TaskManager tm;
//    //tm.execute_front();

    
/*

 0. entity form a base entity messages pair and sends it to the scheduler
 1. add() creates an advisor and putes it on the arbitration_list
 2. Arbitration lisrt - Advisor pop an element
3. add function called on scheduler ((Message, ENtity))
4. Wrap Message & Entity into a Event object event
5. Enqueue the Event into a EventQUEUE
6. Bundle eventes into taks ** 
5. Each task in the task manager defines one or more events that it handles.
An ewvent is a moment in time when a task is to be executedd
THe event manager generates events as need to trigger the excevution of tasks.
 7.So, evcery task is composed of one or more events..
 8.Events are popped from the event queeue and put into a task
 9.Tasks are queued in tasks_list TaskManager
 .
 */
    
void Scheduler::arbitrate(Message m, BaseEntity be)
{
    Arbiter ab;
    Advisor v = ab.decide();
    Scheduler sch;
    sch.add(v.m, v.e);
    
}
    
    
    
    
Event Scheduler::wrap_event( Message *m , BaseEntity *e)
{
    Event event;
    event.getCurrentEntity();
    event.getCurrentMessage();
    return event;
}




 
void Scheduler::add(Message *m, BaseEntity *be)
{
    Event event;
    event.current_message = m;
    event.fsm = be;
    EventManager emgr;
    emgr.add(event);
    
}
