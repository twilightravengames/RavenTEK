//
//  Event.cpp
//  RavenTek
//
//  Created by Walter Gress V on 12/20/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//


#include "Message.hpp"
#include "Event.hpp"
 
Event Event::wrap_message(Message *m, BaseEntity *e)
{
    Event event;
    

    
    event.current_message = m;
    event.fsm = e;
    
    
    return event;
};
