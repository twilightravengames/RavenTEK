//
//  Task.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/20/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//
#pragma once
#ifndef Task_hpp
#define Task_hpp

#include <stdio.h>
#include <list>
#include "Event.hpp"
#include <string>
using namespace std;
/*
The Event Manager is the heart of the scheduler. Each task in the task manager
defines one or more events that it handles. An event is a moment in time
when a task is to be executed. The event manager generates events as needed
to trigger the execution of tasks.
*/
enum classification { TIME_EVENT, FRAME_EVENT, RENDER_EVENT };
 
 class Task
{
public:
    void add(Event e);
    void remove(Event e);
    void retrieve();
    std::list<Event> get_event_list()
     {
         return events_wrapped;
     }
private:
    std::list<Event> events_wrapped;
    int priority;
 
      
    double fire_time;               //when this task is supposed to fire
    classification type_of_event;
    Task wrap_event(Event &e);   //takes an event and wraps it into a task
    
    int start_frame;
    int step_amount_frame;
    int expire_frame;       //after reaching this the task expires and is deleted by the
                            //task manager
    
    std::string task_name;
    
    int frame_budget;       //maximum amount of time allowed to be active
                                
    bool idle;              //flags this as an idle task. should only be executed when
                            //the message pump is empty ( task list is small)
};
#endif /* Task_hpp */
