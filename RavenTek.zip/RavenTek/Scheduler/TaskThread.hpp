//
//  TaskThread.hpp
//  RavenTek
//
//  Created by Walter Gress V on 1/1/20.
//  Copyright © 2020 Walter Gress V. All rights reserved.
//

#ifndef TaskThread_hpp
#define TaskThread_hpp

#include <stdio.h>

class TaskThread
{
public:
    void loop()
    {
        
    }
    
};


#endif /* TaskThread_hpp */
