//
//  EventManager.cpp
//  RavenTek
//
//  Created by Walter Gress V on 12/20/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#include "EventManager.hpp"
   


Task EventManager::poll()
{
//retrievces a batch of events wrapping them into task
    //iterativelyu
    
    TaskManager tm;
    
    Task task;
    
    return task;
}
