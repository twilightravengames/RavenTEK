//
//  TaskManager.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/20/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef TaskManager_hpp
#define TaskManager_hpp

#include <stdio.h>
#include <list>
#include "Task.hpp"
#include "Event.hpp"
#include <iostream>
#include "TaskThread.hpp"
#include <thread>

#include "TimeBlock.hpp"
#include "Clock.hpp"
#include "TaskManager.hpp"
/* GAME GEMS BOOK 3 SECTION 1.1*/

/*
 
 Task Manager handles the regisgtration and organization of tasks.
 Each task has a standardized interface that contains a callback function
 for the manager to execute. THe task manager maintains a list of tasks
 along with scheduling each one - such as start time, execution frequencey,
 duration, priority, and other required propertiese. It might also contain
 a user-data pointer or perfofrmance statistics.
 
 
 The event manager sits in a loop, watches a real-time clock, and soon as target
 time is reached, it fires an event. In a real-time esystem latency is critical.
 If a task takes too long, then it might interferewi the start of the next
 task. Since each task occurs exactly its scheduled time, the time between tasks
 is essentially from the scvheduler's frame of raference.
 */

class TimeBlock;

using namespace std;

class TaskManager
 {
 public:
    std::list<Task> task_list;
     Clock clock;
 
     std::list<TimeBlock> frame_blocks;
    
     
     void add(Task k);
     void add(Event e);   
     
     void remove(Task k);
     Task retrieve();
     void update(); // examines tasks on task_list. if past expire frame deletes that task
                    // executes. Executes task on the front of the list. Calls adjust_tasks()
     void adjust_tasks();  //adjust_tasks reorganizes the task list according to idle flags
                            //and budget and priority
     void run();
     void stop();
     void execute_front();
     Task wrap_event_in_task(Event e); //
     
     bool halted;       //blocks remove function.
     
     static TimeBlock request;
     
     
     void loop()
     {
         cout << "Initializing Scheduler's schedule" << endl;
         //initialize schedule time blocks
         for (int i = 0; i<100;i++)
         {
             TimeBlock *tb = new TimeBlock;
             
         }
         
         
         
         cout << "Initializing Task Manager Thread" << endl;
         while(true)
         {
             //int frame = clock.getFrame();
             //request frame from the clock Frame (asking for a specific size
             //clock checks to see if it can fit
             //that is, iterate through the list seeing if any are less than or equal to
             //the current request
             int request_size = 99999;
             TimeBlock tb;
             tb.task_size = 600;
             //a time block allocated to the thread
             TimeBlock time_block = clock.getFrame(tb);
             
         }
     }
     
     
 private:
     void sort_by_priority();
     void sort_by_idle();
     void sort_by_frame_budget();
     
     
    
 };
 
#endif /* TaskManager_hpp */

/*
 
 Adjust_tasks()
 
 Step 1:    If frame is fragmented, rearrange the frame
 Step 2:    Check to see if prioriry is preserved, if not rearrange the blocks
 Step 3:    If there are no tasks in the task list except the idle task, execute the idle
 Step 4:    Some tasks have a budget, if they exceed their budget they don't run at all
 
 
 
 */
/* add()
       Step 1: Get the frame from the Clock
       Step 2: CHeck to see if the task will fit in the frame
       Step 3: If the frame is fragmented, rearrange the timing in the frame and
               the position in the task list.
       Step 4: If the task is of frame type and has enough free space, the task manager
               inserts the task into the queue and into the frame.
       
     */

/*
 
 
 */
