//
//  TimeBlock.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/20/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef TimeBlock_hpp
#define TimeBlock_hpp

#include <stdio.h>


class TimeBlock
{
public:
    int start_frame_number;
    int end_frame_number;
    int task_size;
    float offset;
};




#endif /* TimeBlock_hpp */
