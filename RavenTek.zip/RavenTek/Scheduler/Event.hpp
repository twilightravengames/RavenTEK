//
//  Event.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/20/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef Event_hpp
#define Event_hpp

#include <stdio.h>
#include <list>
#include "DeliveryEnum.hpp"
#include "Message.hpp"
#include "Entity.hpp"
#include "BaseEntity.hpp"
#include "Event.hpp"
using namespace std;
/*
The Event Manager is the heart of the scheduler. Each task in the task manager
defines one or more events that it handles. An event is a moment in time
when a task is to be executed. The event manager generates events as needed
to trigger the execution of tasks.


*/

class Event
{
public:
  
    //Event(Message cm, BaseEntity bfsm) : current_message(cm), fsm(bfsm) { return;}
    //~Event() { }
    
    /*
    Event(const Event &e)
    {
        e.current_message = current_message;
        e.fsm = fsm;
    }
    */
    
    
   DeliveryEnum task_responsibility;
    
  void *pTaskPayload;                 //any payload that goes along with the responsibility
    
    //#6
  
   Event wrap_message(Message *m, BaseEntity *e);  ///takes a message and wraps it into an event.
   
    void executeFSM(Entity e, Message m); //called when task is up for usage. Uses inheritance.
                    //dispatch() function called on the inherited class calls the
                        //the FSM specific to that Entity
    Message getCurrentMessage() { return *current_message; }
    BaseEntity  getCurrentEntity() { return *fsm; }
    

    Message *current_message;
    BaseEntity *fsm;  //finite state machine
};

#endif /* Event_hpp */
