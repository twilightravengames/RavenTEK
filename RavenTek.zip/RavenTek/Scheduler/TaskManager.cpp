//
//  TaskManager.cpp
//  RavenTek
//
//  Created by Walter Gress V on 12/20/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#include "TaskManager.hpp"
#include "Task.hpp"
#include "Event.hpp"
#include <iostream>
#include <thread>
#include "TaskThread.hpp"
#include <vector>
#include "ThreadPool.hpp"
#include "BaseEntity.hpp"
#include "Task.hpp"
using namespace std;

Task TaskManager::wrap_event_in_task(Event e)
{
    Task task;
    task.add(e);
    return task;
}
void TaskManager::add(Task task)
{
    //adds to the task list
    task_list.push_back(task);
}
void TaskManager::execute_front()
{

    Task task = task_list.back();
    std::list<Event> events = task.get_event_list();
    Event event = events.front();
    events.pop_front();
    BaseEntity base = event.getCurrentEntity();
    Message msg = event.getCurrentMessage();
    base.dispatch(&msg);
    
    std::thread task_thread(&BaseEntity::loop, &base);
    task_thread.detach();
    
    //worker thread
    //std::thread task_thread(&TaskThread::loop, &tt);
    //task_thread.detach();
    // create thread pool with 4 worker threads
    /*ThreadPool pool(4);

    // enqueue and store future
    auto result = pool.enqueue([](int answer) { return answer; }, 42);

    // get result from future
    std::cout << result.get() << std::endl;
    */
    
}

Event wrap_message(Message *m, BaseEntity *e);  ///takes a message and wraps it into an event.

 void executeFSM(Entity e, Message m); //called when task is up for usage. Uses inheritance.
