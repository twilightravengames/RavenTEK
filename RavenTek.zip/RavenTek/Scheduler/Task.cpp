//
//  Task.cpp
//  RavenTek
//
//  Created by Walter Gress V on 12/20/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#include "Task.hpp"


void Task::add(Event e)
{
    events_wrapped.push_back(e);
}

