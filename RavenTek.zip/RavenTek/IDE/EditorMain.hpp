//
//  EditorMain.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/20/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef EditorMain_hpp
#define EditorMain_hpp

#include <stdio.h>



class EditorMain
{
    void executionLoop()
    {
        while(true)
        {
            
        }
    }
};



#endif /* EditorMain_hpp */
