//
//  Packable.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/24/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef Packable_hpp
#define Packable_hpp

#include <stdio.h>


class Packable
{
public:
    virtual ~Packable() = 0;
    virtual int GetBits() const;
    virtual void Pack(char*, int *StartBit) const;
    virtual void Unpack(const char*, int* StartBit);
};


#endif /* Packable_hpp */
