//
//  BitPackingCompressionTechnique.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/24/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef BitPackingCompressionTechnique_hpp
#define BitPackingCompressionTechnique_hpp

/* GEMS GAME BOOK 4 SECTION 6.5 INCOMPLETE*/

#include <stdio.h>
#include "Packable.hpp"
//
template<int N>
class BitPackCodec
{
private:
    Packable *mPackList[N];
    
public:
    void Register(Packable&);
    char *Pack(char*) const;
    void Unpack (const char*) const;
    int GetPackedBytes() const;
    
};


#endif /* BitPackingCompressionTechnique_hpp */
