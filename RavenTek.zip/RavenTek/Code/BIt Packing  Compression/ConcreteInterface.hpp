//
//  ConcreteInterface.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/24/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef ConcreteInterface_hpp
#define ConcreteInterface_hpp

#include <stdio.h>
#include "Packable.hpp"
#include <cstdint>

template< typename T, int Bits>
class PkUint: public Packable {};

template< typename T,uint64_t Min, uint64_t Max>
class PkUintRange : public Packable {};

template< typename T, int64_t Min, int64_t Max>
class PkInt : public Packable {};







#endif /* ConcreteInterface_hpp */
