//
//  PropertyClassForMember Access.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/18/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef PropertyClassForMember_Access_hpp
#define PropertyClassForMember_Access_hpp

#include <stdio.h>
/* BOOK 2 SECTION 1.7*/
#endif /* PropertyClassForMember_Access_hpp */
