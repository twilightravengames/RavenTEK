//
//  FlexibleUILayoutSystemDivergentEnvironments.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/27/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef FlexibleUILayoutSystemDivergentEnvironments_hpp
#define FlexibleUILayoutSystemDivergentEnvironments_hpp

#include <stdio.h>
/* GAME GEMS BOOK 8 SECTION 4.10*/
#endif /* FlexibleUILayoutSystemDivergentEnvironments_hpp */
