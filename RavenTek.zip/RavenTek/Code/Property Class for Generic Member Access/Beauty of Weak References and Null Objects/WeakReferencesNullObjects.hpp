//
//  WeakReferencesNullObjects.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/21/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef WeakReferencesNullObjects_hpp
#define WeakReferencesNullObjects_hpp

#include <stdio.h>
/* GAME GEMS BOOK 4 SECTION 1.7*/
#endif /* WeakReferencesNullObjects_hpp */
