//
//  Fast-IA.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/27/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef Fast_IA_hpp
#define Fast_IA_hpp

#include <stdio.h>

/* GAME GEMS BOOK 8 SECTION 4.1*/
#endif /* Fast_IA_hpp */
