//
//  Linear Rergression.hpp
//  RavenTek
//
//  Created by Walter Gress V on 1/2/20.
//  Copyright © 2020 Walter Gress V. All rights reserved.
//

#ifndef Linear_Rergression_hpp
#define Linear_Rergression_hpp

#include <stdio.h>

#endif /* Linear_Rergression_hpp */
