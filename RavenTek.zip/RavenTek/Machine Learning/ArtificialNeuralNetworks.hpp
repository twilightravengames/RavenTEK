//
//  ArtificialNeuralNetworks.hpp
//  RavenTek
//
//  Created by Walter Gress V on 1/2/20.
//  Copyright © 2020 Walter Gress V. All rights reserved.
//

#ifndef ArtificialNeuralNetworks_hpp
#define ArtificialNeuralNetworks_hpp

#include <stdio.h>

#endif /* ArtificialNeuralNetworks_hpp */
