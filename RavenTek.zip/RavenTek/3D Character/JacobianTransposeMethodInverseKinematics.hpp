//
//  JacobianTransposeMethodInverseKinematics.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/22/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef JacobianTransposeMethodInverseKinematics_hpp
#define JacobianTransposeMethodInverseKinematics_hpp

#include <stdio.h>

/* GAME GEMS BOOK 4 SECTION 2.6*/

#endif /* JacobianTransposeMethodInverseKinematics_hpp */
