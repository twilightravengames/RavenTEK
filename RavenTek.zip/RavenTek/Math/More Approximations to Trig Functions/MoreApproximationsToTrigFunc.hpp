//
//  MoreApproximationsToTrigFunc.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/21/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef MoreApproximationsToTrigFunc_hpp
#define MoreApproximationsToTrigFunc_hpp

#include <stdio.h>

/* GAME GEMS BOOK 3 SECTION 2.3*/

#endif /* MoreApproximationsToTrigFunc_hpp */
