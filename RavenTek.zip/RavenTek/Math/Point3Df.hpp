//
//  Point3Df.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/30/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef Point3Df_hpp
#define Point3Df_hpp

#include <stdio.h>

class Point3Df
{
    float x,y,z;
};

#endif /* Point3Df_hpp */
