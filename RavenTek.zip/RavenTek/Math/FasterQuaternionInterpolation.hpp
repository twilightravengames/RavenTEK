//
//  FasterQuaternionInterpolation.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/24/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef FasterQuaternionInterpolation_hpp
#define FasterQuaternionInterpolation_hpp

#include <stdio.h>
/* GAME GEMS BOOK 5 SECTION 2.4*/
#endif /* FasterQuaternionInterpolation_hpp */
