//
//  LinearLookupTaableSineCosine.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/19/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef LinearLookupTaableSineCosine_hpp
#define LinearLookupTaableSineCosine_hpp

#include <stdio.h>
/* GEMS GAME BOOK 2 SECTION 2.1*/
#endif /* LinearLookupTaableSineCosine_hpp */
