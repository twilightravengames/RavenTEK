//
//  ProjectiveSpaceToImprovePrecisionGeometricComp.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/27/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef ProjectiveSpaceToImprovePrecisionGeometricComp_hpp
#define ProjectiveSpaceToImprovePrecisionGeometricComp_hpp

#include <stdio.h>

/* GAME ENGE BOOK7 SECTION 2.4*/

#endif /* ProjectiveSpaceToImprovePrecisionGeometricComp_hpp */
