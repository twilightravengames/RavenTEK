//
//  Point3D.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/30/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef Point3D_hpp
#define Point3D_hpp

#include <stdio.h>

class Point3D
{
    int x,y,z;
};

#endif /* Point3D_hpp */
