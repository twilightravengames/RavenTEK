//
//  FastMetaProgramming.hpp
//  NecroTek3D
//
//  Created by Walter Gress V on 12/2/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef FastMetaProgramming_hpp
#define FastMetaProgramming_hpp

#include <stdio.h>
/*
 
 Fast Math Using Template Metaprogramming
 Graphics Gems Book 1 Section 1.2
 
 
 */
#endif /* FastMetaProgramming_hpp */
