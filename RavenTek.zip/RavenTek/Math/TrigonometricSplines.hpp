//
//  TrigonometricSplines.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/27/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef TrigonometricSplines_hpp
#define TrigonometricSplines_hpp

#include <stdio.h>
/* GAW GEMS BOOK 7 SECTIOn 2.7*/
#endif /* TrigonometricSplines_hpp */
