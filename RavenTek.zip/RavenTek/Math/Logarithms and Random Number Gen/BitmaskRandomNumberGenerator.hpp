//
//  BitmaskRandomNumberGenerator.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/21/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef BitmaskRandomNumberGenerator_hpp
#define BitmaskRandomNumberGenerator_hpp

#include <stdio.h>
/* GEMS GAME BOOK 3 SECTION 2.1*/
#endif /* BitmaskRandomNumberGenerator_hpp */
