//
//  Vec3D.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/20/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef Vec3D_hpp
#define Vec3D_hpp

#include <stdio.h>

class Vec3D
{
public:
    int i;
    int j;
    int k;
};


#endif /* Vec3D_hpp */
