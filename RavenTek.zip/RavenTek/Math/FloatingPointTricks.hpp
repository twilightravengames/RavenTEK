//
//  FloatingPointTricks.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/25/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef FloatingPointTricks_hpp
#define FloatingPointTricks_hpp

#include <stdio.h>
/*GAME GEMS SECRION 2.1*/
#endif /* FloatingPointTricks_hpp */
