//
//  FastDataLoadTrick.hpp
//  NecroTek3D
//
//  Created by Walter Gress V on 12/2/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef FastDataLoadTrick_hpp
#define FastDataLoadTrick_hpp

#include <stdio.h>

/*
 Graphics Gems 1 Section 1.8
 
 
 */


#endif /* FastDataLoadTrick_hpp */
