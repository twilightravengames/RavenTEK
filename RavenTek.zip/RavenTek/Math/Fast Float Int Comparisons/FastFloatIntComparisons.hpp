//
//  FastFloatIntComparisons.hpp
//  RavenTek
//
//  Created by Walter Gress V on 12/19/19.
//  Copyright © 2019 Walter Gress V. All rights reserved.
//

#ifndef FastFloatIntComparisons_hpp
#define FastFloatIntComparisons_hpp

#include <stdio.h>
/* GEMS GAME BOOK 2 SECTION 2.1*/
#endif /* FastFloatIntComparisons_hpp */
